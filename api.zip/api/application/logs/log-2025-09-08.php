<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-08 06:12:21 --> 404 Page Not Found: Env/index
