<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-08-22 06:30:43 --> Config Class Initialized
INFO - 2025-08-22 06:30:43 --> Hooks Class Initialized
DEBUG - 2025-08-22 06:30:43 --> UTF-8 Support Enabled
INFO - 2025-08-22 06:30:43 --> Utf8 Class Initialized
INFO - 2025-08-22 06:30:43 --> URI Class Initialized
INFO - 2025-08-22 06:30:43 --> Router Class Initialized
INFO - 2025-08-22 06:30:43 --> Output Class Initialized
INFO - 2025-08-22 06:30:43 --> Security Class Initialized
DEBUG - 2025-08-22 06:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-22 06:30:43 --> Input Class Initialized
INFO - 2025-08-22 06:30:43 --> Language Class Initialized
INFO - 2025-08-22 06:30:43 --> Loader Class Initialized
INFO - 2025-08-22 06:30:43 --> Helper loaded: url_helper
INFO - 2025-08-22 06:30:43 --> Helper loaded: html_helper
INFO - 2025-08-22 06:30:43 --> Helper loaded: form_helper
INFO - 2025-08-22 06:30:43 --> Helper loaded: file_helper
INFO - 2025-08-22 06:30:43 --> Helper loaded: json_output_helper
INFO - 2025-08-22 06:30:43 --> Helper loaded: custom_helper
INFO - 2025-08-22 06:30:43 --> Helper loaded: security_helper
INFO - 2025-08-22 06:30:43 --> Database Driver Class Initialized
INFO - 2025-08-22 06:30:43 --> Email Class Initialized
DEBUG - 2025-08-22 06:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-22 06:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-22 06:30:43 --> Form Validation Class Initialized
INFO - 2025-08-22 06:30:43 --> Model "Setting_model" initialized
INFO - 2025-08-22 06:30:43 --> Controller Class Initialized
INFO - 2025-08-22 06:30:43 --> Model "Staff_model" initialized
INFO - 2025-08-22 06:30:43 --> Model "Setting_model" initialized
DEBUG - 2025-08-22 06:30:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2025-08-22 06:30:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2025-08-22 06:30:43 --> Encryption Class Initialized
INFO - 2025-08-22 06:30:43 --> Model "Teacher_auth_model" initialized
DEBUG - 2025-08-22 06:30:43 --> Enc_lib class already loaded. Second attempt ignored.
DEBUG - 2025-08-22 06:30:43 --> Teacher login attempt for email: teacher@gmail.com
DEBUG - 2025-08-22 06:30:43 --> Database query returned 0 rows
DEBUG - 2025-08-22 06:30:43 --> No staff record found for email: teacher@gmail.com
INFO - 2025-08-22 06:30:43 --> Final output sent to browser
DEBUG - 2025-08-22 06:30:43 --> Total execution time: 0.1242
INFO - 2025-08-22 06:31:20 --> Config Class Initialized
INFO - 2025-08-22 06:31:20 --> Hooks Class Initialized
DEBUG - 2025-08-22 06:31:20 --> UTF-8 Support Enabled
INFO - 2025-08-22 06:31:20 --> Utf8 Class Initialized
INFO - 2025-08-22 06:31:20 --> URI Class Initialized
INFO - 2025-08-22 06:31:20 --> Router Class Initialized
INFO - 2025-08-22 06:31:20 --> Output Class Initialized
INFO - 2025-08-22 06:31:20 --> Security Class Initialized
DEBUG - 2025-08-22 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-22 06:31:20 --> Input Class Initialized
INFO - 2025-08-22 06:31:20 --> Language Class Initialized
INFO - 2025-08-22 06:31:20 --> Loader Class Initialized
INFO - 2025-08-22 06:31:20 --> Helper loaded: url_helper
INFO - 2025-08-22 06:31:20 --> Helper loaded: html_helper
INFO - 2025-08-22 06:31:20 --> Helper loaded: form_helper
INFO - 2025-08-22 06:31:20 --> Helper loaded: file_helper
INFO - 2025-08-22 06:31:20 --> Helper loaded: json_output_helper
INFO - 2025-08-22 06:31:20 --> Helper loaded: custom_helper
INFO - 2025-08-22 06:31:20 --> Helper loaded: security_helper
INFO - 2025-08-22 06:31:20 --> Database Driver Class Initialized
INFO - 2025-08-22 06:31:20 --> Email Class Initialized
DEBUG - 2025-08-22 06:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-22 06:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-22 06:31:20 --> Form Validation Class Initialized
INFO - 2025-08-22 06:31:20 --> Model "Setting_model" initialized
INFO - 2025-08-22 06:31:20 --> Controller Class Initialized
INFO - 2025-08-22 06:31:20 --> Model "Staff_model" initialized
INFO - 2025-08-22 06:31:20 --> Model "Setting_model" initialized
DEBUG - 2025-08-22 06:31:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2025-08-22 06:31:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2025-08-22 06:31:20 --> Encryption Class Initialized
INFO - 2025-08-22 06:31:20 --> Model "Teacher_auth_model" initialized
DEBUG - 2025-08-22 06:31:20 --> Enc_lib class already loaded. Second attempt ignored.
DEBUG - 2025-08-22 06:31:20 --> Teacher login attempt for email: teacher@gmail.com
DEBUG - 2025-08-22 06:31:20 --> Database query returned 1 rows
DEBUG - 2025-08-22 06:31:20 --> Found staff record with ID: 31
DEBUG - 2025-08-22 06:31:20 --> Password verification result: FAIL
INFO - 2025-08-22 06:31:20 --> Final output sent to browser
DEBUG - 2025-08-22 06:31:20 --> Total execution time: 0.1015
INFO - 2025-08-22 06:31:54 --> Config Class Initialized
INFO - 2025-08-22 06:31:54 --> Hooks Class Initialized
DEBUG - 2025-08-22 06:31:54 --> UTF-8 Support Enabled
INFO - 2025-08-22 06:31:54 --> Utf8 Class Initialized
INFO - 2025-08-22 06:31:54 --> URI Class Initialized
INFO - 2025-08-22 06:31:54 --> Router Class Initialized
INFO - 2025-08-22 06:31:54 --> Output Class Initialized
INFO - 2025-08-22 06:31:54 --> Security Class Initialized
DEBUG - 2025-08-22 06:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-22 06:31:54 --> Input Class Initialized
INFO - 2025-08-22 06:31:54 --> Language Class Initialized
INFO - 2025-08-22 06:31:54 --> Loader Class Initialized
INFO - 2025-08-22 06:31:54 --> Helper loaded: url_helper
INFO - 2025-08-22 06:31:54 --> Helper loaded: html_helper
INFO - 2025-08-22 06:31:54 --> Helper loaded: form_helper
INFO - 2025-08-22 06:31:54 --> Helper loaded: file_helper
INFO - 2025-08-22 06:31:54 --> Helper loaded: json_output_helper
INFO - 2025-08-22 06:31:54 --> Helper loaded: custom_helper
INFO - 2025-08-22 06:31:54 --> Helper loaded: security_helper
INFO - 2025-08-22 06:31:54 --> Database Driver Class Initialized
INFO - 2025-08-22 06:31:54 --> Email Class Initialized
DEBUG - 2025-08-22 06:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-22 06:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-22 06:31:54 --> Form Validation Class Initialized
INFO - 2025-08-22 06:31:54 --> Model "Setting_model" initialized
INFO - 2025-08-22 06:31:54 --> Controller Class Initialized
INFO - 2025-08-22 06:31:54 --> Model "Staff_model" initialized
INFO - 2025-08-22 06:31:54 --> Model "Setting_model" initialized
DEBUG - 2025-08-22 06:31:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2025-08-22 06:31:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2025-08-22 06:31:54 --> Encryption Class Initialized
INFO - 2025-08-22 06:31:54 --> Model "Teacher_auth_model" initialized
DEBUG - 2025-08-22 06:31:54 --> Enc_lib class already loaded. Second attempt ignored.
DEBUG - 2025-08-22 06:31:54 --> Teacher login attempt for email: teacher@gmail.com
DEBUG - 2025-08-22 06:31:54 --> Database query returned 1 rows
DEBUG - 2025-08-22 06:31:54 --> Found staff record with ID: 31
DEBUG - 2025-08-22 06:31:54 --> Password verification result: FAIL
INFO - 2025-08-22 06:31:54 --> Final output sent to browser
DEBUG - 2025-08-22 06:31:54 --> Total execution time: 0.0938
INFO - 2025-08-22 06:32:29 --> Config Class Initialized
INFO - 2025-08-22 06:32:29 --> Hooks Class Initialized
DEBUG - 2025-08-22 06:32:29 --> UTF-8 Support Enabled
INFO - 2025-08-22 06:32:29 --> Utf8 Class Initialized
INFO - 2025-08-22 06:32:29 --> URI Class Initialized
INFO - 2025-08-22 06:32:29 --> Router Class Initialized
INFO - 2025-08-22 06:32:29 --> Output Class Initialized
INFO - 2025-08-22 06:32:29 --> Security Class Initialized
DEBUG - 2025-08-22 06:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-22 06:32:29 --> Input Class Initialized
INFO - 2025-08-22 06:32:29 --> Language Class Initialized
INFO - 2025-08-22 06:32:29 --> Loader Class Initialized
INFO - 2025-08-22 06:32:29 --> Helper loaded: url_helper
INFO - 2025-08-22 06:32:29 --> Helper loaded: html_helper
INFO - 2025-08-22 06:32:29 --> Helper loaded: form_helper
INFO - 2025-08-22 06:32:29 --> Helper loaded: file_helper
INFO - 2025-08-22 06:32:29 --> Helper loaded: json_output_helper
INFO - 2025-08-22 06:32:29 --> Helper loaded: custom_helper
INFO - 2025-08-22 06:32:29 --> Helper loaded: security_helper
INFO - 2025-08-22 06:32:29 --> Database Driver Class Initialized
INFO - 2025-08-22 06:32:29 --> Email Class Initialized
DEBUG - 2025-08-22 06:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-22 06:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-22 06:32:29 --> Form Validation Class Initialized
INFO - 2025-08-22 06:32:29 --> Model "Setting_model" initialized
INFO - 2025-08-22 06:32:29 --> Controller Class Initialized
INFO - 2025-08-22 06:32:29 --> Model "Staff_model" initialized
INFO - 2025-08-22 06:32:29 --> Model "Setting_model" initialized
DEBUG - 2025-08-22 06:32:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2025-08-22 06:32:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2025-08-22 06:32:29 --> Encryption Class Initialized
INFO - 2025-08-22 06:32:29 --> Model "Teacher_auth_model" initialized
DEBUG - 2025-08-22 06:32:29 --> Enc_lib class already loaded. Second attempt ignored.
DEBUG - 2025-08-22 06:32:29 --> Teacher login attempt for email: teacher@gmail.com
DEBUG - 2025-08-22 06:32:29 --> Database query returned 1 rows
DEBUG - 2025-08-22 06:32:29 --> Found staff record with ID: 31
DEBUG - 2025-08-22 06:32:29 --> Password verification result: PASS
INFO - 2025-08-22 06:32:29 --> Final output sent to browser
DEBUG - 2025-08-22 06:32:29 --> Total execution time: 0.1090
INFO - 2025-08-22 06:32:36 --> Config Class Initialized
INFO - 2025-08-22 06:32:36 --> Hooks Class Initialized
DEBUG - 2025-08-22 06:32:36 --> UTF-8 Support Enabled
INFO - 2025-08-22 06:32:36 --> Utf8 Class Initialized
INFO - 2025-08-22 06:32:36 --> URI Class Initialized
INFO - 2025-08-22 06:32:36 --> Router Class Initialized
INFO - 2025-08-22 06:32:36 --> Output Class Initialized
INFO - 2025-08-22 06:32:36 --> Security Class Initialized
DEBUG - 2025-08-22 06:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-22 06:32:36 --> Input Class Initialized
INFO - 2025-08-22 06:32:36 --> Language Class Initialized
INFO - 2025-08-22 06:32:36 --> Loader Class Initialized
INFO - 2025-08-22 06:32:36 --> Helper loaded: url_helper
INFO - 2025-08-22 06:32:36 --> Helper loaded: html_helper
INFO - 2025-08-22 06:32:36 --> Helper loaded: form_helper
INFO - 2025-08-22 06:32:36 --> Helper loaded: file_helper
INFO - 2025-08-22 06:32:36 --> Helper loaded: json_output_helper
INFO - 2025-08-22 06:32:36 --> Helper loaded: custom_helper
INFO - 2025-08-22 06:32:36 --> Helper loaded: security_helper
INFO - 2025-08-22 06:32:36 --> Database Driver Class Initialized
INFO - 2025-08-22 06:32:36 --> Email Class Initialized
DEBUG - 2025-08-22 06:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-22 06:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-22 06:32:36 --> Form Validation Class Initialized
INFO - 2025-08-22 06:32:36 --> Model "Setting_model" initialized
INFO - 2025-08-22 06:32:36 --> Controller Class Initialized
INFO - 2025-08-22 06:32:36 --> Model "Staff_model" initialized
INFO - 2025-08-22 06:32:36 --> Model "Setting_model" initialized
DEBUG - 2025-08-22 06:32:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2025-08-22 06:32:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2025-08-22 06:32:36 --> Encryption Class Initialized
INFO - 2025-08-22 06:32:36 --> Model "Teacher_auth_model" initialized
DEBUG - 2025-08-22 06:32:36 --> Enc_lib class already loaded. Second attempt ignored.
INFO - 2025-08-22 06:32:36 --> Final output sent to browser
DEBUG - 2025-08-22 06:32:36 --> Total execution time: 0.1711
ERROR - 2025-08-22 06:35:56 --> Query error: Unknown column 'app_key' in 'field list' - Invalid query: UPDATE `staff` SET `app_key` = 'optional_device_token'
WHERE `id` = '2'
ERROR - 2025-08-22 06:36:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'digita90_digidineuser'@'localhost' (using password: YES) C:\xampp\htdocs\amt\api\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-08-22 06:36:40 --> Unable to connect to the database
ERROR - 2025-08-22 06:36:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'digita90_digidineuser'@'localhost' (using password: YES) C:\xampp\htdocs\amt\api\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-08-22 06:36:40 --> Unable to connect to the database
ERROR - 2025-08-22 06:36:40 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\amt\api\system\database\drivers\mysqli\mysqli_driver.php 401
ERROR - 2025-08-22 06:36:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'digita90_digidineuser'@'localhost' (using password: YES) C:\xampp\htdocs\amt\api\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-08-22 06:36:45 --> Unable to connect to the database
ERROR - 2025-08-22 06:36:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'digita90_digidineuser'@'localhost' (using password: YES) C:\xampp\htdocs\amt\api\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-08-22 06:36:45 --> Unable to connect to the database
ERROR - 2025-08-22 06:36:45 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\amt\api\system\database\drivers\mysqli\mysqli_driver.php 401
ERROR - 2025-08-22 06:36:57 --> Query error: Unknown column 'app_key' in 'field list' - Invalid query: UPDATE `staff` SET `app_key` = 'optional_device_token'
WHERE `id` = '2'
ERROR - 2025-08-22 04:51:44 --> Query error: Unknown column 'app_key' in 'SET' - Invalid query: UPDATE `staff` SET `app_key` = 'dmju4wQVyzY:APA91bGV8MUPod52ykp0DH9ip8QBMjjJC1NZJ_GJyoXk2Kk0DavKQDT9YimKI3a-HmK_0fKd_e4fWQ0Vxer2TIae61dWxebxxFOHt8zlwOTOXPjMMe31wY8'
WHERE `id` = '6'
ERROR - 2025-08-22 04:58:37 --> Query error: Unknown column 'app_key' in 'WHERE' - Invalid query: UPDATE `staff` SET `app_key` = NULL
WHERE `app_key` = 'dmju4wQVyzY:APA91bGV8MUPod52ykp0DH9ip8QBMjjJC1NZJ_GJyoXk2Kk0DavKQDT9YimKI3a-HmK_0fKd_e4fWQ0Vxer2TIae61dWxebxxFOHt8zlwOTOXPjMMe31wY8'
