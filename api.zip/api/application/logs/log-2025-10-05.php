<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-05 00:09:41 --> Exception: Too few arguments to function json_output(), 1 passed in C:\xampp\htdocs\amt\api\application\controllers\Teacher_webservice.php on line 2554 and exactly 2 expected in C:\xampp\htdocs\amt\api\application\helpers\json_output_helper.php on line 5
ERROR - 2025-10-05 00:09:41 --> Exception: Too few arguments to function json_output(), 1 passed in C:\xampp\htdocs\amt\api\application\controllers\Teacher_webservice.php on line 2554 and exactly 2 expected in C:\xampp\htdocs\amt\api\application\helpers\json_output_helper.php on line 5
ERROR - 2025-10-05 14:02:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Feegroup_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-10-05 14:04:04 --> Severity: Warning --> Undefined property: Fee_group_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-05 14:04:04 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Feegroup_model.php 13
ERROR - 2025-10-05 14:04:47 --> Severity: Warning --> Undefined property: Fee_group_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-05 14:04:47 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Feegroup_model.php 13
ERROR - 2025-10-05 14:05:50 --> Severity: error --> Exception: Call to undefined method Customlib::getUserData() C:\xampp\htdocs\amt\api\application\models\Class_model.php 42
ERROR - 2025-10-05 14:06:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-10-05 14:07:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-10-05 14:07:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-10-05 14:08:23 --> Severity: Warning --> Undefined property: Student_fee_payment_search_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-05 14:08:23 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Studentfeemaster_model.php 19
