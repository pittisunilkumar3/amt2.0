<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-02 21:56:40 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 21:56:49 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 21:57:04 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 21:57:39 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:00:12 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\amt\api\system\core\URI.php 102
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\amt\api\system\core\Router.php 128
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$benchmark is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$hooks is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$config is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$log is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$utf8 is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$uri is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$exceptions is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$router is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$output is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$security is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$input is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$lang is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$db is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 397
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\amt\api\system\database\DB_driver.php 372
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$email is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 303
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 328
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 355
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 365
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 366
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 367
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 368
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 426
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 110
ERROR - 2025-10-02 22:12:04 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 137
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$session is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$form_validation is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$Setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$customlib is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$staff_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$encryption is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$enc_lib is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property JWT_lib::$CI is deprecated C:\xampp\htdocs\amt\api\application\libraries\JWT_lib.php 17
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$jwt_lib is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$teacher_auth_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:04 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:12:04 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$teacher_middleware is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\amt\api\system\core\URI.php 102
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\amt\api\system\core\Router.php 128
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$benchmark is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$hooks is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$config is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$log is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$utf8 is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$uri is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$exceptions is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$router is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$output is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$security is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$input is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$lang is deprecated C:\xampp\htdocs\amt\api\system\core\Controller.php 83
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$db is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 397
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\amt\api\system\database\DB_driver.php 372
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$email is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 303
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 328
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 355
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 365
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 366
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 367
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 368
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 426
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 110
ERROR - 2025-10-02 22:12:52 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\amt\api\system\libraries\Session\Session.php 137
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$session is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$form_validation is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$Setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$customlib is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$staff_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$encryption is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$enc_lib is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property JWT_lib::$CI is deprecated C:\xampp\htdocs\amt\api\application\libraries\JWT_lib.php 17
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$jwt_lib is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$teacher_auth_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-10-02 22:12:52 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:12:52 --> Severity: 8192 --> Creation of dynamic property Teacher_webservice::$teacher_middleware is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-10-02 22:16:15 --> 404 Page Not Found: Teacher/simple_menu
ERROR - 2025-10-02 22:16:15 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:16:39 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:16:39 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:16:40 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:17:18 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:17:18 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:17:18 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:19:56 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:19:56 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:19:56 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:23:16 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:23:16 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:23:16 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:27:50 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:27:50 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:27:50 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:27:50 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:28:16 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:32:05 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:32:05 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:32:05 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:32:31 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:34:24 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-02 22:38:33 --> Error loading models: Unable to locate the model you have specified: Role_model
