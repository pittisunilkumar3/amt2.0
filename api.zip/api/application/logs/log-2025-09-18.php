<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-18 13:58:38 --> Query error: Unknown column 'app_key' in 'field list' - Invalid query: UPDATE `staff` SET `app_key` = 'optional_device_token'
WHERE `id` = '6'
ERROR - 2025-09-18 14:00:25 --> Query error: Unknown column 'app_key' in 'field list' - Invalid query: UPDATE `staff` SET `app_key` = 'optional_device_token'
WHERE `id` = '6'
ERROR - 2025-09-18 14:25:19 --> Severity: Compile Error --> Cannot redeclare Teacher_auth::profile() C:\xampp\htdocs\amt\api\application\controllers\Teacher_auth.php 339
ERROR - 2025-09-18 17:02:30 --> Teacher profile API error: Unable to locate the model you have specified: Payroll_model
ERROR - 2025-09-18 17:03:26 --> Severity: error --> Exception: Class "MY_Model" not found C:\xampp\htdocs\amt\api\application\models\Payroll_model.php 3
