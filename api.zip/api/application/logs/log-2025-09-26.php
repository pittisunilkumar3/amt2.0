<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-26 09:30:03 --> 404 Page Not Found: Api/teacher
ERROR - 2025-09-26 09:30:07 --> 404 Page Not Found: Api/teacher
ERROR - 2025-09-26 10:47:49 --> 404 Page Not Found: Login/index
ERROR - 2025-09-26 20:32:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:32:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:32:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:32:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:32:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:32:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:32:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:33:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:33:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:34:55 --> Severity: error --> Exception: Class "MY_Model" not found C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 3
ERROR - 2025-09-26 20:35:25 --> Severity: error --> Exception: Class "MY_Model" not found C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 3
ERROR - 2025-09-26 20:36:41 --> Severity: 8192 --> Creation of dynamic property Test_basic::$agent is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-09-26 20:36:41 --> Severity: Warning --> Undefined property: Test_basic::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-09-26 20:37:02 --> Severity: 8192 --> Creation of dynamic property Test_basic::$agent is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-09-26 20:37:02 --> Severity: 8192 --> Creation of dynamic property Test_basic::$setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:37:02 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_session is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 11
ERROR - 2025-09-26 20:37:02 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_date is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 12
ERROR - 2025-09-26 20:37:02 --> Severity: 8192 --> Creation of dynamic property Test_basic::$staffattendancemodel is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:37:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\amt\api\system\core\Exceptions.php:272) C:\xampp\htdocs\amt\api\system\core\Common.php 571
ERROR - 2025-09-26 20:37:12 --> Severity: 8192 --> Creation of dynamic property Test_basic::$agent is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-09-26 20:37:12 --> Severity: 8192 --> Creation of dynamic property Test_basic::$setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:37:12 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_session is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 11
ERROR - 2025-09-26 20:37:12 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_date is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 12
ERROR - 2025-09-26 20:37:12 --> Severity: 8192 --> Creation of dynamic property Test_basic::$staffattendancemodel is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:37:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\amt\api\system\core\Exceptions.php:272) C:\xampp\htdocs\amt\api\system\core\Common.php 571
ERROR - 2025-09-26 20:37:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:38:14 --> Severity: 8192 --> Creation of dynamic property Test_basic::$agent is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-09-26 20:38:14 --> Severity: 8192 --> Creation of dynamic property Test_basic::$setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:38:14 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_session is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 11
ERROR - 2025-09-26 20:38:14 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_date is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 12
ERROR - 2025-09-26 20:38:14 --> Severity: 8192 --> Creation of dynamic property Test_basic::$staffattendancemodel is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:38:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\amt\api\system\core\Exceptions.php:272) C:\xampp\htdocs\amt\api\system\core\Common.php 571
ERROR - 2025-09-26 20:39:13 --> Severity: 8192 --> Creation of dynamic property Test_basic::$agent is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 1284
ERROR - 2025-09-26 20:39:13 --> Severity: 8192 --> Creation of dynamic property Test_basic::$setting_model is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:39:13 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_session is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 11
ERROR - 2025-09-26 20:39:13 --> Severity: 8192 --> Creation of dynamic property Staffattendancemodel::$current_date is deprecated C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php 12
ERROR - 2025-09-26 20:39:13 --> Severity: 8192 --> Creation of dynamic property Test_basic::$staffattendancemodel is deprecated C:\xampp\htdocs\amt\api\system\core\Loader.php 359
ERROR - 2025-09-26 20:39:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\amt\api\system\core\Exceptions.php:272) C:\xampp\htdocs\amt\api\system\core\Common.php 571
ERROR - 2025-09-26 20:53:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:54:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:54:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:55:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:55:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:57:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:58:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:58:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 20:58:01 --> 404 Page Not Found: Teacher/index
ERROR - 2025-09-26 21:00:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-09-26 21:01:19 --> 404 Page Not Found: Teacher/debug_test
ERROR - 2025-09-26 21:05:01 --> 404 Page Not Found: Teacher/debug_test
ERROR - 2025-09-26 21:05:10 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:05:19 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:06:18 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:06:30 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:06:46 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:07:38 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:10:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:10:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:10:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:10:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:10:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:10:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:10:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:12:34 --> Query error: Unknown column 'sat.attendencetype' in 'field list' - Invalid query: SELECT `sat`.`attendencetype`, COUNT(*) as count
FROM `staff_attendance` `sa`
JOIN `staff_attendance_type` `sat` ON `sa`.`staff_attendance_type_id` = `sat`.`id`
WHERE `sa`.`date` >= '2024-08-01'
AND `sa`.`date` <= '2024-08-31'
GROUP BY `sat`.`attendencetype`
ERROR - 2025-09-26 21:12:34 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\amt\api\application\controllers\Database_verification.php 101
ERROR - 2025-09-26 21:12:40 --> Query error: Unknown column 'sat.attendencetype' in 'field list' - Invalid query: SELECT `sat`.`attendencetype`, COUNT(*) as count
FROM `staff_attendance` `sa`
JOIN `staff_attendance_type` `sat` ON `sa`.`staff_attendance_type_id` = `sat`.`id`
WHERE `sa`.`date` >= '2024-08-01'
AND `sa`.`date` <= '2024-08-31'
GROUP BY `sat`.`attendencetype`
ERROR - 2025-09-26 21:12:40 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\amt\api\application\controllers\Database_verification.php 101
ERROR - 2025-09-26 21:14:11 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:14:11 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:14:11 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:27 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:15:33 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:16:28 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:16:34 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:16:54 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:16:54 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:21:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:21:33 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:22:23 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:32:09 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:33:41 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:33:50 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:36:51 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:37:01 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:37:09 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:38:01 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:38:01 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:38:01 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:38:01 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-09-26 21:49:34 --> Error loading models: Unable to locate the model you have specified: Role_model
