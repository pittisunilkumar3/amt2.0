<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-14 13:46:19 --> 404 Page Not Found: Api/vendor
