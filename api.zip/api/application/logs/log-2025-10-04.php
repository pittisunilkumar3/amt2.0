<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-04 20:34:00 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:34:00 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:34:00 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:34:00 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:34:37 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:34:38 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:34:38 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:34:38 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:39:41 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:39:41 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:40:53 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:40:53 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:41:44 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:41:44 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:58 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:58 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:58 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:58 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:58 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:58 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:59 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:59 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:59 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-04 20:56:59 --> Error loading models: Unable to locate the model you have specified: Role_model
