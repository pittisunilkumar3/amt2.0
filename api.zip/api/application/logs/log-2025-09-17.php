<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-17 20:40:13 --> Query error: Unknown column 'app_key' in 'WHERE' - Invalid query: UPDATE `staff` SET `app_key` = NULL
WHERE `app_key` = 'e3JnseTYxqA:APA91bGOSxSeo0_RtlSRkKuIZq2mWMSnTTCi_WQayAgVIPGZee2_naxNiisr_nvuI2dMmpazq1zer1CUpBrQ89rZOy5s-54oer9XUklr3IeBKzr4-65OeUQ'
ERROR - 2025-09-17 21:02:22 --> Query error: Unknown column 'app_key' in 'WHERE' - Invalid query: UPDATE `staff` SET `app_key` = NULL
WHERE `app_key` = 'e3JnseTYxqA:APA91bGOSxSeo0_RtlSRkKuIZq2mWMSnTTCi_WQayAgVIPGZee2_naxNiisr_nvuI2dMmpazq1zer1CUpBrQ89rZOy5s-54oer9XUklr3IeBKzr4-65OeUQ'
