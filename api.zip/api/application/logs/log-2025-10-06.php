<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-06 08:35:27 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:35:59 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:36:24 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:40:07 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:43:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:54:52 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:57:52 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:59:00 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:00:10 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:03:18 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:11:33 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:12:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:42:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:12:44 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:42:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:15:36 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:45:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:15:37 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:45:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:15:37 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:45:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:16:19 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:16:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:16:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:31:14 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 11:45:31 --> Severity: Warning --> Undefined property: Auth::$language_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-06 11:45:31 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\amt\api\application\models\Setting_model.php 131
ERROR - 2025-10-06 11:52:35 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 15:24:09 --> Severity: Warning --> Undefined array key "user_type" C:\xampp\htdocs\amt\api\application\controllers\Webservice.php 358
ERROR - 2025-10-06 15:24:09 --> Severity: error --> Exception: Call to undefined method Setting_model::student_fields() C:\xampp\htdocs\amt\api\application\controllers\Webservice.php 361
ERROR - 2025-10-06 11:54:09 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 15:25:09 --> Severity: Warning --> Attempt to read property "category" on null C:\xampp\htdocs\amt\api\application\controllers\Webservice.php 364
ERROR - 2025-10-06 15:25:09 --> Severity: error --> Exception: Attempt to assign property "category" on null C:\xampp\htdocs\amt\api\application\controllers\Webservice.php 365
ERROR - 2025-10-06 11:55:09 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 11:55:30 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 11:55:54 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 13:11:55 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 13:14:10 --> Query error: Unknown column 'activelanguage' in 'field list' - Invalid query: SELECT `id`, `student_panel_login`, `parent_panel_login`, `student_login`, `parent_login`, `name`, `timezone`, `activelanguage`
FROM `sch_settings`
ORDER BY `id`
 LIMIT 1
ERROR - 2025-10-06 13:14:11 --> Query error: Unknown column 'activelanguage' in 'field list' - Invalid query: SELECT `id`, `student_panel_login`, `parent_panel_login`, `student_login`, `parent_login`, `name`, `timezone`, `activelanguage`
FROM `sch_settings`
ORDER BY `id`
 LIMIT 1
ERROR - 2025-10-06 13:14:11 --> Query error: Unknown column 'activelanguage' in 'field list' - Invalid query: SELECT `id`, `student_panel_login`, `parent_panel_login`, `student_login`, `parent_login`, `name`, `timezone`, `activelanguage`
FROM `sch_settings`
ORDER BY `id`
 LIMIT 1
ERROR - 2025-10-06 13:15:29 --> Query error: Unknown column 'activelanguage' in 'field list' - Invalid query: SELECT `id`, `student_panel_login`, `parent_panel_login`, `student_login`, `parent_login`, `name`, `timezone`, `activelanguage`
FROM `sch_settings`
ORDER BY `id`
 LIMIT 1
ERROR - 2025-10-06 13:15:51 --> Query error: Unknown column 'activelanguage' in 'field list' - Invalid query: SELECT `id`, `student_panel_login`, `parent_panel_login`, `student_login`, `parent_login`, `name`, `timezone`, `activelanguage`
FROM `sch_settings`
ORDER BY `id`
 LIMIT 1
ERROR - 2025-10-06 13:15:51 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 13:16:14 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 13:16:14 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 13:18:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 13:18:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 13:18:02 --> Auth_model login() - Failed to enable student login: No changes made - setting may already be correct
ERROR - 2025-10-06 13:18:26 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 13:18:26 --> Severity: Warning --> Undefined array key "student_login" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 288
ERROR - 2025-10-06 13:18:26 --> Severity: Warning --> Undefined array key "parent_login" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 289
ERROR - 2025-10-06 13:18:26 --> Severity: Warning --> Undefined array key "short_name" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 97
ERROR - 2025-10-06 13:18:43 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 13:18:43 --> Severity: Warning --> Undefined array key "student_login" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 289
ERROR - 2025-10-06 13:18:43 --> Severity: Warning --> Undefined array key "parent_login" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 290
ERROR - 2025-10-06 13:20:39 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 13:20:39 --> Severity: Warning --> Undefined array key "student_login" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 289
ERROR - 2025-10-06 13:20:39 --> Severity: Warning --> Undefined array key "parent_login" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 290
ERROR - 2025-10-06 13:20:39 --> Severity: Warning --> Undefined array key "short_name" C:\xampp\htdocs\amt\api\application\models\Auth_model.php 98
ERROR - 2025-10-06 13:24:05 --> Auth_model login() - Login blocked, student_panel_login = "0"
ERROR - 2025-10-06 13:25:25 --> Auth_model login() - Login blocked, student_panel_login = "0"
ERROR - 2025-10-06 13:35:46 --> Auth_model login() - Login blocked, student_panel_login = "0"
ERROR - 2025-10-06 13:48:47 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 17:18:48 --> PHP Error: Creation of dynamic property Staffattendancemodel::$current_session is deprecated in C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php on line 11
ERROR - 2025-10-06 17:18:48 --> PHP Error: Creation of dynamic property Staffattendancemodel::$current_date is deprecated in C:\xampp\htdocs\amt\api\application\models\Staffattendancemodel.php on line 12
ERROR - 2025-10-06 17:18:48 --> PHP Error: Creation of dynamic property Teacher_webservice::$staffattendancemodel is deprecated in C:\xampp\htdocs\amt\api\system\core\Loader.php on line 359
ERROR - 2025-10-06 17:18:48 --> PHP Error: Creation of dynamic property Teacher_webservice::$leaverequest_model is deprecated in C:\xampp\htdocs\amt\api\system\core\Loader.php on line 359
ERROR - 2025-10-06 15:59:40 --> Auth_model login() - Login blocked, student_panel_login = "0"
ERROR - 2025-10-06 17:20:18 --> Error loading models: Unable to locate the model you have specified: Schoolhouse_model
ERROR - 2025-10-06 17:20:18 --> Severity: Warning --> Undefined property: Student_house_api::$setting_model C:\xampp\htdocs\amt\api\application\controllers\Student_house_api.php 54
ERROR - 2025-10-06 17:20:18 --> Severity: error --> Exception: Call to a member function getSetting() on null C:\xampp\htdocs\amt\api\application\controllers\Student_house_api.php 54
ERROR - 2025-10-06 17:24:54 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:14:35 --> Error loading models: Unable to locate the model you have specified: Disable_reason_model
ERROR - 2025-10-06 18:14:35 --> Severity: Warning --> Undefined property: Disable_reason_api::$setting_model C:\xampp\htdocs\amt\api\application\controllers\Disable_reason_api.php 54
ERROR - 2025-10-06 18:14:35 --> Severity: error --> Exception: Call to a member function getSetting() on null C:\xampp\htdocs\amt\api\application\controllers\Disable_reason_api.php 54
ERROR - 2025-10-06 21:47:07 --> Severity: error --> Exception: Undefined constant "INSERT_RECORD_CONSTANT" C:\xampp\htdocs\amt\api\application\models\Disable_reason_model.php 98
ERROR - 2025-10-06 18:18:40 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:19:47 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:19:47 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:19:47 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:21:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:21:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 22:18:58 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\amt\api\application\controllers\Student_report_api.php 283
ERROR - 2025-10-06 18:48:58 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:52:01 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:01 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 18:52:02 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 18:52:02 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 18:52:02 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 16:52:02 --> Severity: Warning --> Undefined property: Class_section_report_api::$student_model C:\xampp\htdocs\amt\api\application\controllers\Class_section_report_api.php 178
ERROR - 2025-10-06 18:52:02 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 18:52:02 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 18:52:02 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 18:52:02 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 16:52:02 --> Severity: Warning --> Undefined property: Class_section_report_api::$student_model C:\xampp\htdocs\amt\api\application\controllers\Class_section_report_api.php 178
ERROR - 2025-10-06 18:52:02 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 18:52:02 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 16:52:02 --> Severity: Warning --> Undefined property: Class_section_report_api::$student_model C:\xampp\htdocs\amt\api\application\controllers\Class_section_report_api.php 178
ERROR - 2025-10-06 22:25:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-06 22:25:08 --> Severity: error --> Exception: Call to undefined method Student_model::studentGuardianDetails() C:\xampp\htdocs\amt\api\application\controllers\Guardian_report_api.php 107
ERROR - 2025-10-06 18:55:08 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 19:12:58 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 19:12:58 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 19:12:58 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-06 19:12:58 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-06 22:42:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-06 22:42:58 --> Severity: error --> Exception: Call to undefined method Student_model::studentGuardianDetails() C:\xampp\htdocs\amt\api\application\controllers\Guardian_report_api.php 107
ERROR - 2025-10-06 22:42:59 --> Severity: error --> Exception: Call to undefined method Student_model::admissionYear() C:\xampp\htdocs\amt\api\application\controllers\Admission_report_api.php 341
ERROR - 2025-10-06 22:42:59 --> Severity: error --> Exception: Call to undefined method Student_model::getdtforlogincredential() C:\xampp\htdocs\amt\api\application\controllers\Login_detail_report_api.php 99
ERROR - 2025-10-06 22:42:59 --> Severity: error --> Exception: Call to undefined method Student_model::getdtforlogincredential() C:\xampp\htdocs\amt\api\application\controllers\Parent_login_detail_report_api.php 100
ERROR - 2025-10-06 19:12:59 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-06 19:12:59 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-06 19:12:59 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-06 19:12:59 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-06 19:12:59 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-06 19:12:59 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
