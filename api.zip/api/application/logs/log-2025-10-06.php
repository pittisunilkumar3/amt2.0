<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-06 08:35:27 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:35:59 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:36:24 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:40:07 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:43:26 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:54:52 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:57:52 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 08:59:00 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:00:10 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:03:18 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:11:33 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:12:13 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:42:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:12:44 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:42:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:15:36 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:45:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:15:37 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:45:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:15:37 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 12:45:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `s...' at line 1 - Invalid query: SELECT `DISTINCT` `c`.`id`, `c`.`class` as `class_name`, `c`.`is_active`
FROM `student_session` `ss`
INNER JOIN `classes` `c` ON `c`.`id` = `ss`.`class_id`
WHERE `ss`.`session_id` = '7'
ORDER BY `c`.`class` ASC
ERROR - 2025-10-06 09:16:19 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:16:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:16:20 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-06 09:31:14 --> Error loading models: Unable to locate the model you have specified: Role_model
