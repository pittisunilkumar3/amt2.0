<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-07 06:42:21 --> Error loading models in Class_section_report_api: Unable to locate the model you have specified: Classsection_model
ERROR - 2025-10-07 06:42:21 --> Severity: Warning --> Undefined array key "WARNING" C:\xampp\htdocs\amt\api\system\core\Log.php 181
ERROR - 2025-10-07 10:17:27 --> Severity: error --> Exception: Call to undefined method Student_model::searchdatatableByClassSectionCategoryGenderRte() C:\xampp\htdocs\amt\api\application\controllers\Student_report_api.php 194
ERROR - 2025-10-07 10:17:27 --> Severity: error --> Exception: Call to undefined method Student_model::searchdatatableByClassSectionCategoryGenderRte() C:\xampp\htdocs\amt\api\application\controllers\Student_report_api.php 194
ERROR - 2025-10-07 10:17:27 --> Severity: error --> Exception: Call to undefined method Student_model::searchdatatableByClassSectionCategoryGenderRte() C:\xampp\htdocs\amt\api\application\controllers\Student_report_api.php 194
ERROR - 2025-10-07 10:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:17:27 --> Severity: error --> Exception: Call to undefined method Student_model::studentGuardianDetails() C:\xampp\htdocs\amt\api\application\controllers\Guardian_report_api.php 202
ERROR - 2025-10-07 10:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:17:27 --> Severity: error --> Exception: Call to undefined method Student_model::studentGuardianDetails() C:\xampp\htdocs\amt\api\application\controllers\Guardian_report_api.php 202
ERROR - 2025-10-07 10:17:28 --> Severity: error --> Exception: Call to undefined method Student_model::getdtforlogincredential() C:\xampp\htdocs\amt\api\application\controllers\Login_detail_report_api.php 176
ERROR - 2025-10-07 10:17:29 --> Severity: error --> Exception: Call to undefined method Student_model::getdtforlogincredential() C:\xampp\htdocs\amt\api\application\controllers\Login_detail_report_api.php 176
ERROR - 2025-10-07 10:17:29 --> Severity: error --> Exception: Call to undefined method Student_model::getdtforlogincredential() C:\xampp\htdocs\amt\api\application\controllers\Parent_login_detail_report_api.php 184
ERROR - 2025-10-07 10:17:29 --> Severity: error --> Exception: Call to undefined method Student_model::getdtforlogincredential() C:\xampp\htdocs\amt\api\application\controllers\Parent_login_detail_report_api.php 184
ERROR - 2025-10-07 06:47:29 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 06:47:29 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 06:47:29 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 06:47:29 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 06:47:29 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 06:47:29 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 10:18:14 --> Severity: error --> Exception: Call to undefined method Student_model::searchdatatableByClassSectionCategoryGenderRte() C:\xampp\htdocs\amt\api\application\controllers\Student_report_api.php 194
ERROR - 2025-10-07 10:21:54 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:21:55 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:21:55 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:24:44 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:24:44 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:24:44 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:24:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:24:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:24:46 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:24:46 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:24:46 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:24:46 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 06:54:46 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 06:54:46 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 06:54:46 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 06:54:46 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 06:54:47 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 06:54:47 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 10:27:13 --> Unable to load the requested class: Datatables
ERROR - 2025-10-07 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:31:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:31:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:31:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:31:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:31:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:31:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 07:01:12 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:01:12 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 07:01:12 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:01:12 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 07:01:12 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:01:12 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 10:32:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:33:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:33:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:33:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:33:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:33:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:33:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 10:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:33:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:34:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 10:34:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\libraries\Datatables.php 504
ERROR - 2025-10-07 07:04:00 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:04:00 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 07:04:00 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:04:00 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 07:04:01 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:04:01 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 11:07:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 11:07:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
ERROR - 2025-10-07 07:37:45 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:37:45 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 07:37:45 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:37:45 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 07:37:45 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 07:37:45 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 11:40:35 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `students`.`id` ASC
ERROR - 2025-10-07 11:40:47 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `students`.`id` ASC
ERROR - 2025-10-07 08:32:09 --> Error loading models: Unable to locate the model you have specified: Role_model
ERROR - 2025-10-07 10:16:11 --> Severity: Warning --> Undefined property: Login_detail_report_api::$auth_model C:\xampp\htdocs\amt\api\application\controllers\Login_detail_report_api.php 90
ERROR - 2025-10-07 10:16:11 --> Severity: error --> Exception: Call to a member function check_auth_client() on null C:\xampp\htdocs\amt\api\application\controllers\Login_detail_report_api.php 90
ERROR - 2025-10-07 11:06:34 --> Severity: Warning --> Undefined property: Class_subject_report_api::$setting_model C:\xampp\htdocs\amt\api\system\core\Model.php 74
ERROR - 2025-10-07 11:06:34 --> Severity: error --> Exception: Call to a member function getCurrentSession() on null C:\xampp\htdocs\amt\api\application\models\Subjecttimetable_model.php 13
ERROR - 2025-10-07 17:29:46 --> Severity: error --> Exception: Call to undefined method Onlineexam_model::onlineexamReport() C:\xampp\htdocs\amt\api\application\controllers\Online_exams_report_api.php 87
ERROR - 2025-10-07 17:32:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'date_format(onlineexam.created_at,'%Y-%m-%d') between '2025-01-01' and '2025-...' at line 1 - Invalid query: SELECT student_session.id,students.admission_no,students.id as sid, CONCAT_WS(' ',firstname,middlename,lastname) as name,firstname,middlename,lastname,GROUP_CONCAT(onlineexam.id,'@',onlineexam.exam,'@',onlineexam.attempt,'@',onlineexam.exam_from,'@',onlineexam.exam_to,'@',onlineexam.duration,'@',onlineexam.passing_percentage,'@',onlineexam.is_active,'@',onlineexam.publish_result) as exams,GROUP_CONCAT(onlineexam_students.onlineexam_id) as attempt,`classes`.`id` AS `class_id`, `student_session`.`id` as `student_session_id`, `students`.`id`, `classes`.`class`, `sections`.`id` AS `section_id`, `sections`.`section`, `students`.`id`, `students`.`admission_no` FROM `student_session` INNER JOIN onlineexam_students on onlineexam_students.student_session_id=student_session.id INNER JOIN students on students.id=student_session.student_id JOIN `classes` ON `student_session`.`class_id` = `classes`.`id` JOIN `sections` ON `sections`.`id` = `student_session`.`section_id` LEFT JOIN `categories` ON `students`.`category_id` = `categories`.`id` INNER JOIN onlineexam on onlineexam_students.onlineexam_id=onlineexam.id WHERE students.is_active='yes'  date_format(onlineexam.created_at,'%Y-%m-%d') between '2025-01-01' and '2025-12-31' GROUP BY student_session.id ORDER BY students.id
ERROR - 2025-10-07 17:45:45 --> Query error: Column 'created_at' in where clause is ambiguous - Invalid query: SELECT onlineexam.*,(select count(*) from onlineexam_students WHERE onlineexam_students.onlineexam_id = onlineexam.id) as assign,(select count(*) from onlineexam_questions where onlineexam_questions.onlineexam_id=onlineexam.id) as questions FROM `onlineexam` inner join onlineexam_students on onlineexam_students.onlineexam_id=onlineexam.id inner join student_session on student_session.id=onlineexam_students.student_session_id where 1=1 AND  date_format(created_at,'%Y-%m-%d') between '2025-01-01' and '2025-12-31' GROUP BY onlineexam.id ORDER BY onlineexam.id DESC
ERROR - 2025-10-07 17:46:49 --> Query error: Column 'created_at' in where clause is ambiguous - Invalid query: SELECT onlineexam.*,(select count(*) from onlineexam_students WHERE onlineexam_students.onlineexam_id = onlineexam.id) as assign,(select count(*) from onlineexam_questions where onlineexam_questions.onlineexam_id=onlineexam.id) as questions FROM `onlineexam` inner join onlineexam_students on onlineexam_students.onlineexam_id=onlineexam.id inner join student_session on student_session.id=onlineexam_students.student_session_id where 1=1 AND  date_format(created_at,'%Y-%m-%d') between '2025-01-01' and '2025-12-31' GROUP BY onlineexam.id ORDER BY onlineexam.id DESC
ERROR - 2025-10-07 21:39:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Subjectgroup_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-10-07 21:40:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Subject_model C:\xampp\htdocs\amt\api\system\core\Loader.php 349
ERROR - 2025-10-07 21:50:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\amt\api\application\models\Class_model.php 43
